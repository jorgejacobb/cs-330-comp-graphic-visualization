///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{

	// destroy the created OpenGL textures
	DestroyGLTextures();

	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	// Force all images to load as RGBA (avoids alignment crashes)
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		STBI_rgb_alpha);

	// Force channel count to 4
	colorChannels = 4;


	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		glTexImage2D(
			GL_TEXTURE_2D,
			0,
			GL_RGBA8,
			width,
			height,
			0,
			GL_RGBA,
			GL_UNSIGNED_BYTE,
			image);


		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
		m_textureIDs[i].ID = 0;
		m_textureIDs[i].tag = "/0";
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	// quartz texture for bookshelf structure
	bReturn = CreateGLTexture("textures/quartz.jpg", "quartzTex");

	// quartz1 texture for the floor plane
	bReturn = CreateGLTexture("textures/quartz1.jpg", "quartz1Tex");

	// sphere texture
	bReturn = CreateGLTexture("textures/marble.jpg", "sphereTex");

	// bind loaded textures to GPU slots
	BindGLTextures();
}


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load textures first
	LoadSceneTextures();

	DefineObjectMaterials();
	SetupSceneLights();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();

}

/***********************************************************
* DefineObjectMaterials()
*
* Configuring material settings used by the Phong shader.
* At least one material must exist for lighting to render correctly.
***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	m_objectMaterials.clear();

	OBJECT_MATERIAL floorTile;
	floorTile.diffuseColor = glm::vec3(0.85f, 0.85f, 0.85f);
	floorTile.specularColor = glm::vec3(0.50f, 0.50f, 0.50f);
	floorTile.shininess = 16.0f;
	floorTile.tag = "floorTile";
	m_objectMaterials.push_back(floorTile);

	OBJECT_MATERIAL woodShelf;
	woodShelf.diffuseColor = glm::vec3(0.80f, 0.75f, 0.70f);
	woodShelf.specularColor = glm::vec3(0.20f, 0.20f, 0.20f);
	woodShelf.shininess = 8.0f;
	woodShelf.tag = "woodShelf";
	m_objectMaterials.push_back(woodShelf);

	OBJECT_MATERIAL marbleSphere;
	marbleSphere.diffuseColor = glm::vec3(0.90f, 0.90f, 0.90f);
	marbleSphere.specularColor = glm::vec3(0.80f, 0.80f, 0.80f);
	marbleSphere.shininess = 64.0f;
	marbleSphere.tag = "marbleSphere";
	m_objectMaterials.push_back(marbleSphere);

}

/***********************************************************
* SetupSceneLights()
*
* Enable lighting and configure light sources for the scene.
***********************************************************/
void SceneManager::SetupSceneLights()
{
	//enables Phong lighting in the fragment shader
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// 1) Main light: Directional (brighter indoor fill)
	m_pShaderManager->setVec3Value("directionalLight.direction", 0.0f, -1.0f, 0.0f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.30f, 0.30f, 0.30f);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.70f, 0.70f, 0.70f);
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.25f, 0.25f, 0.25f);
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// 2) Fill light: Point (warm indoor)
	m_pShaderManager->setVec3Value("pointLights[0].position", 1.5f, 5.0f, 3.0f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.25f, 0.22f, 0.18f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 1.0f, 0.95f, 0.85f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.30f, 0.30f, 0.30f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// 3) Back fill (soft) to keep rear visible
	m_pShaderManager->setVec3Value("pointLights[1].position", 0.0f, 4.5f, -2.0f);
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.12f, 0.12f, 0.12f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.80f, 0.80f, 0.80f);
	m_pShaderManager->setVec3Value("pointLights[1].specular", 0.10f, 0.10f, 0.10f);
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	// Turn off unused point lights 
	for (int i = 2; i < 5; i++)
	{
		std::string base = "pointLights[" + std::to_string(i) + "].bActive";
		m_pShaderManager->setBoolValue(base.c_str(), false);
	}
	m_pShaderManager->setBoolValue("spotLight.bActive", false);
}


/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("floorTile");

	// Floor uses quartz1 texture
	SetShaderTexture("quartz1Tex");

	// Complex technique requirement (tiling)
	SetTextureUVScale(4.0f, 4.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	// -----------------------------
	// WALL (Plane)
	// -----------------------------
	// const float wallWidth = 20.0f;
	// const float wallHeight = 8.0f;

	// scaleXYZ = glm::vec3(wallWidth, 1.0f, wallHeight);

	// Vertical
	// XrotationDegrees = -90.0f;
	// YrotationDegrees = 0.0f;
	// ZrotationDegrees = 0.0f;

	// Bottom y = 0
	// positionXYZ = glm::vec3(0.0f, wallHeight / 2.0f, -5.0f);

	// SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.85f, 0.85f, 0.85f, 1.0f);
	// m_basicMeshes->DrawPlaneMesh();


	// -----------------------------
	// BOOKSHELF (Boxes)
	// -----------------------------
	// Bookshelf dimensions
	const float shelfWidth = 6.0f;
	const float shelfHeight = 7.0f;
	const float shelfDepth = 1.6f; //more depth

	const float panelThickness = 0.2f;
	const float shelfThickness = 0.15f;
	const float backThickness = 0.05f;  // <- back panel thickness

	// Bookshelf position (centered)
	const float centerX = 0.0f;
	const float centerZ = 0.0f;

	// Bookshelf uses quartz texture
	SetShaderTexture("quartzTex");

	// Making the texture readable on thin boards
	SetTextureUVScale(2.0f, 2.0f);

	SetShaderMaterial("woodShelf");


	// 1) Left side panel
	scaleXYZ = glm::vec3(panelThickness, shelfHeight, shelfDepth);
	positionXYZ = glm::vec3(centerX - (shelfWidth / 2.0f) + (panelThickness / 2.0f),
		shelfHeight / 2.0f,
		centerZ);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	// 2) Right side panel
	scaleXYZ = glm::vec3(panelThickness, shelfHeight, shelfDepth);
	positionXYZ = glm::vec3(centerX + (shelfWidth / 2.0f) - (panelThickness / 2.0f),
		shelfHeight / 2.0f,
		centerZ);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();


	// --- Shelves (5 total), evenly spaced and inset between side panels ---
	const int shelfCount = 5;

	// Make shelves fit BETWEEN the side panels (better proportions)
	const float innerWidth = shelfWidth - (2.0f * panelThickness);

	// Define vertical range for shelves
	const float yBottom = shelfThickness * 0.5f;                    // sits on floor
	const float yTopLimit = shelfHeight - (shelfThickness * 1.5f);  // leave space under top cap

	const float step = (yTopLimit - yBottom) / (shelfCount - 1);

	for (int i = 0; i < shelfCount; i++)
	{
		float y = yBottom + (step * i);

		scaleXYZ = glm::vec3(innerWidth, shelfThickness, shelfDepth - backThickness);
		positionXYZ = glm::vec3(centerX, y, centerZ + (backThickness / 2.0f));

		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
		m_basicMeshes->DrawBoxMesh();
	}

	// --- Top cap (keeps the frame look) ---
	scaleXYZ = glm::vec3(shelfWidth, shelfThickness, shelfDepth - backThickness);
	positionXYZ = glm::vec3(centerX,
		shelfHeight - (shelfThickness * 0.5f),
		centerZ + (backThickness / 2.0f));


	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	// -----------------------------
	// DECOR SPHERE (above bookshelf)
	// -----------------------------

	// Texture
	SetShaderMaterial("marbleSphere");
	SetShaderTexture("sphereTex");
	SetTextureUVScale(1.0f, 1.0f);

	// Size + placement (sit on top of bookshelf)
	float sphereScale = 0.9f;                 // size 
	float sphereRadius = sphereScale * 0.5f;   // radius 

	scaleXYZ = glm::vec3(sphereScale, sphereScale, sphereScale);

	// Move RIGHT = +X, sit on TOP = shelfHeight + radius
	positionXYZ = glm::vec3(
		centerX + 1.0f,                         // right
		shelfHeight + sphereRadius + 0.40f,      // down/up 
		centerZ                                  // keep depth centered
	);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawSphereMesh();

// -----------------------------
// PLANT (on top of bookshelf)
// -----------------------------

// Use lighting, no texture (solid colors)
	m_pShaderManager->setBoolValue(g_UseTextureName, false);
	SetTextureUVScale(1.0f, 1.0f);

	// --- Pot (cylinder textured) ---
	SetShaderMaterial("woodShelf");
	SetShaderTexture("sphereTex");   // reusing marble texture
	SetTextureUVScale(1.0f, 1.0f);

	scaleXYZ = glm::vec3(0.6f, 0.5f, 0.6f);

	positionXYZ = glm::vec3(
		centerX - 1.5f,
		shelfHeight + 0.03f,
		centerZ
	);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// --- Plant (cone) ---
	scaleXYZ = glm::vec3(0.8f, 1.0f, 0.8f);

	positionXYZ = glm::vec3(
		centerX - 1.5f,
		shelfHeight + 0.5f,   // above pot
		centerZ
	);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.2f, 0.6f, 0.25f, 1.0f); // green
	m_basicMeshes->DrawConeMesh();


	// -----------------------------
	// BOOKS ON ALL SHELVES (Green Tones)
	// -----------------------------

	m_pShaderManager->setIntValue(g_UseTextureName, false);
	SetShaderMaterial("woodShelf");

	for (int i = 0; i < shelfCount - 1; i++)  // exclude top shelf
	{
		float y = yBottom + (step * i);
		float bookBaseY = y + 0.6f;

		// Alternate sides
		float sideOffset = (i % 2 == 0) ? -1.5f : 0.8f;

		// Book 1 - Emerald Green
		scaleXYZ = glm::vec3(0.4f, 1.2f, 0.6f);
		positionXYZ = glm::vec3(centerX + sideOffset, bookBaseY, centerZ);
		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
		SetShaderColor(0.05f, 0.60f, 0.35f, 1.0f);
		m_basicMeshes->DrawBoxMesh();

		// Book 2 - Bright Leaf Green
		scaleXYZ = glm::vec3(0.35f, 1.0f, 0.6f);
		positionXYZ = glm::vec3(centerX + sideOffset + 0.5f, bookBaseY - 0.1f, centerZ);
		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
		SetShaderColor(0.15f, 0.70f, 0.25f, 1.0f);
		m_basicMeshes->DrawBoxMesh();

		// Book 3 - Fresh Green
		scaleXYZ = glm::vec3(0.45f, 1.1f, 0.6f);
		positionXYZ = glm::vec3(centerX + sideOffset + 1.0f, bookBaseY - 0.05f, centerZ);
		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
		SetShaderColor(0.30f, 0.80f, 0.20f, 1.0f);
		m_basicMeshes->DrawBoxMesh();

		// Book 4 - Deep Forest Green
		scaleXYZ = glm::vec3(0.3f, 0.9f, 0.6f);
		positionXYZ = glm::vec3(centerX + sideOffset + 1.4f, bookBaseY - 0.15f, centerZ);
		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
		SetShaderColor(0.05f, 0.45f, 0.20f, 1.0f);
		m_basicMeshes->DrawBoxMesh();
	}


}
